######## INSTALLATION FOR MY WEB APPLICATION ##############


STEP 1: YOU MUST IMPORT THE laurence.sql in localhost.
STEP 2: AFTER YOU UPLOADED THE FILE. THE DATABASE NAME IS "laurence" DATABASE TABLE IS "tbl_lau".
STEP 3: NOW VISIT THIS LINK: http://localhost/Laurence/Lau_cont/main