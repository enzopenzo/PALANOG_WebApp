<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Lau_cont extends CI_Controller
{
    /**
     * summary
     */
    function main(){

    	$data['tbl_d'] = $this->lau_d->getdata();
    	$this->load->view('main/index',$data);
    }

    function __construct()
    {
    	parent:: __construct();
    	$this->load->model('data','lau_d');
    }

    function home(){
		$data['person'] = $this->lau_d->getdata();
    	$this->load->view('main/home',$data);
    }
}


?>