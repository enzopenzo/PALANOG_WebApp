<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">
	<title><?php  
						if ($person) {
							foreach ($person as $data) {
							    echo $data->fname." ".$data->lname;
							}
						}
					?></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>

	<main>
			
			<!-- header -->
		<header>
			<div class="head">
				<center><span>Personal Information</span></center>
			</div>
		</header>
		<!-- end of header -->

		<div class="list">
			<ul>
				<li><a title="About Me" href="<?php echo base_url('Lau_cont/main') ?>">Back</a></li>
			</ul>
		</div>

		<!-- home img -->

		<div class="box">
			<div class="flex_box">
				<div class="txt_head">
					<h4><?php  
						if ($person) {
							foreach ($person as $data) {
							    echo $data->nickname;
							}
						}
					?></h4>
					<p><?php  
						if ($person) {
							foreach ($person as $data) {
							    echo $data->msg;
							}
						}
					?></p>
				</div>
				<div class="img_box">
					<img src="<?php echo base_url();?>assets/images/a.jpg" alt="Image" width="300" height="300">
				</div>
			</div>
		</div>

		<!-- end of home img -->

	</main>


	
</body>
</html>