<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="https://fonts.googleapis.com/css2?family=Fira+Sans&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
	<title><?php  

		if ($tbl_d) {
			foreach ($tbl_d as $data) {
			    echo $data->fname." ".$data->lname;
			}
		}

	?></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>

	<main>
			<!-- header -->
		<header>
			<div class="head">
				<a href="<?php echo base_url('Lau_cont/main'); ?>"><span>Web Application</span></a>
			</div>
		</header>

		<!-- end of header -->

<!-- btn -->
		<div class="list">
			<ul>
				<li><a title="About Me">About Me</a></li>
				<!-- <li><a title="Edit">Story</a></li> -->
				<li><a title="Personal" id="per">Personal</a></li>
				<li><a title="Home" href="<?php echo base_url('Lau_cont/home'); ?>">Home</a></li>
			</ul>
		</div>
		<!-- end of btn -->

		<!-- personal -->
		<div class="block">
			<div class="box">
				<div class="content">
					<div class="img">
						<img id="id" src="<?php echo base_url();?>assets/images/lau1.jpg" alt="Photo" width="200" height="200">
					</div>
					<div class="text">
					    <ul>
					    	<li><span>Name: <?php  
							if ($tbl_d) {
								foreach ($tbl_d as $data) {
								    echo $data->fname." ".$data->lname;
								}
							}
							?></span></li>
					    	<li><span>Email: <?php  
							if ($tbl_d) {
								foreach ($tbl_d as $data) {
								    echo $data->email;
								}
							}
							?></span></li>
					    	<li><span>Motto: <?php  
							if ($tbl_d) {
								foreach ($tbl_d as $data) {
								    echo $data->motto;
								}
							}
							?></span></li>
					    	<li><span>Contact: <?php  
							if ($tbl_d) {
								foreach ($tbl_d as $data) {
								    echo $data->contact;
								}
							}
							?></span></li>
					    	<!-- <li><span>Name: Laurence Angchangco Palanog</span></li> -->
					    </ul>
					</div>
					<img id="img" src="<?php echo base_url();?>assets/svg/times-solid.svg" alt="Close" width="20" height="20" onclick="close_per();" title="Exit">
				</div>
			</div>
		</div>
		<!-- end of personal -->

		



	</main>


	<script type="text/javascript">
			
		var a = document.querySelector(".block");

		window.onload = addEventListener();

		function addEventListener() {
			if (window.addEventListener) {
				var di = document.getElementById('per').addEventListener('click',display_per,false);
			}
		}

		function display_per(){
			a.classList.add('bg-active');
		}
		function close_per(){
			a.classList.remove('bg-active');
		}

	</script>


	
</body>
</html>